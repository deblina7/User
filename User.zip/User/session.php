<?php
session_start();
//   $count = 0;
//   if(isset($_SESSION['cart'])){
//     $count = count($_SESSION['cart']);
//   }
?>